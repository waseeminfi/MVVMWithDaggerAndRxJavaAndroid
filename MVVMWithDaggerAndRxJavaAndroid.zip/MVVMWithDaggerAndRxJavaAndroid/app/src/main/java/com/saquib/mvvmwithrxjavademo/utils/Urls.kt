package com.saquib.mvvmwithrxjavademo.utils

/**
 * Created by ${Saquib} on 03-05-2018.
 */
object Urls {
    const val BASE_URL = "http://xyz/" //put your base url here
    const val LOGIN = "abc" //put your end point here
}