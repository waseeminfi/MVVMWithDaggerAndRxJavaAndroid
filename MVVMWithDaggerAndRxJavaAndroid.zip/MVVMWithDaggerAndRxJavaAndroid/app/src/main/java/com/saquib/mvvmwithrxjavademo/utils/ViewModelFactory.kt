package com.saquib.mvvmwithrxjavademo.utils

import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProvider
import com.saquib.mvvmwithrxjavademo.login.LoginViewModel
import com.saquib.mvvmwithrxjavademo.login.Repository
import javax.inject.Inject

/**
 * Created by ${Saquib} on 03-05-2018.
 */
class ViewModelFactory @Inject constructor(private val repository: Repository) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown class name")
    }

}