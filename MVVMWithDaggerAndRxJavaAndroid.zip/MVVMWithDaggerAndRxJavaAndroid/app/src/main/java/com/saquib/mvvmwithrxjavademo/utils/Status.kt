package com.saquib.mvvmwithrxjavademo.utils

/**
 * Created by ${Saquib} on 03-05-2018.
 */
enum class Status {
    LOADING, SUCCESS, ERROR
}