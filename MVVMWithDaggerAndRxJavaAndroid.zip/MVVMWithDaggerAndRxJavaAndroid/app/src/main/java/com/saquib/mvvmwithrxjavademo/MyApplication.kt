package com.saquib.mvvmwithrxjavademo

import android.app.Application
import android.content.Context
import com.saquib.mvvmwithrxjavademo.di.AppComponent
import com.saquib.mvvmwithrxjavademo.di.AppModule

import com.saquib.mvvmwithrxjavademo.di.UtilsModule

/**
 * Created by ${Saquib} on 03-05-2018.
 */
class MyApplication : Application() {
    var appComponent: AppComponent? = null
    var context: Context? = null
    override fun onCreate() {
        super.onCreate()
        context = this
        appComponent = DaggerAppComponent.builder().appModule(AppModule(this)).utilsModule(UtilsModule()).build()
    }

    override fun attachBaseContext(context: Context) {
        super.attachBaseContext(context)
    }
}