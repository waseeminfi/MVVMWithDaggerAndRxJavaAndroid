package com.saquib.mvvmwithrxjavademo.login

import android.app.ProgressDialog
import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.google.gson.JsonElement
import com.saquib.mvvmwithrxjavademo.MyApplication
import com.saquib.mvvmwithrxjavademo.R
import com.saquib.mvvmwithrxjavademo.utils.ApiResponse
import com.saquib.mvvmwithrxjavademo.utils.Constant
import com.saquib.mvvmwithrxjavademo.utils.Status
import com.saquib.mvvmwithrxjavademo.utils.ViewModelFactory
import javax.inject.Inject

/**
 * Created by ${Saquib} on 03-05-2018.
 */
class LoginActivity : AppCompatActivity() {
    @Inject
    var viewModelFactory: ViewModelFactory? = null
    @BindView(R.id.phone_no)
    var phoneNo: EditText? = null
    @BindView(R.id.password)
    var password: EditText? = null
    var viewModel: LoginViewModel? = null
    var progressDialog: ProgressDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)
        progressDialog = Constant.getProgressDialog(this, "Please wait...")
        ButterKnife.bind(this)
        (application as MyApplication).appComponent!!.doInjection(this)
        viewModel = ViewModelProviders.of(this, viewModelFactory).get(LoginViewModel::class.java)
        viewModel!!.loginResponse().observe(this, Observer { apiResponse: ApiResponse? -> consumeResponse(apiResponse) })
    }

    @OnClick(R.id.login)
    fun onLoginClicked() {
        if (isValid) {
            if (!Constant.checkInternetConnection(this)) {
                Toast.makeText(this@LoginActivity, resources.getString(R.string.network_error), Toast.LENGTH_SHORT).show()
            } else {
                viewModel!!.hitLoginApi(phoneNo!!.text.toString(), password!!.text.toString())
            }
        }
    }

    /*
     * method to validate $(mobile number) and $(password)
     * */
    private val isValid: Boolean
        private get() {
            if (phoneNo!!.text.toString().trim { it <= ' ' }.isEmpty()) {
                Toast.makeText(this@LoginActivity, resources.getString(R.string.enter_valid_mobile), Toast.LENGTH_SHORT).show()
                return false
            } else if (password!!.text.toString().trim { it <= ' ' }.isEmpty()) {
                Toast.makeText(this@LoginActivity, resources.getString(R.string.enter_valid_password), Toast.LENGTH_SHORT).show()
                return false
            }
            return true
        }

    /*
     * method to handle response
     * */
    private fun consumeResponse(apiResponse: ApiResponse?) {
        when (apiResponse!!.status) {
            Status.LOADING -> progressDialog!!.show()
            Status.SUCCESS -> {
                progressDialog!!.dismiss()
                renderSuccessResponse(apiResponse.data)
            }
            Status.ERROR -> {
                progressDialog!!.dismiss()
                Toast.makeText(this@LoginActivity, resources.getString(R.string.errorString), Toast.LENGTH_SHORT).show()
            }
            else -> {
            }
        }
    }

    /*
    * method to handle success response
    * */
    private fun renderSuccessResponse(response: JsonElement?) {
        if (!response!!.isJsonNull) {
            Log.d("response=", response.toString())
        } else {
            Toast.makeText(this@LoginActivity, resources.getString(R.string.errorString), Toast.LENGTH_SHORT).show()
        }
    }
}